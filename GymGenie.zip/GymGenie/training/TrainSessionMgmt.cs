﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GymGenie.training
{
    class TrainSessionMgmt
    {
    }
}
